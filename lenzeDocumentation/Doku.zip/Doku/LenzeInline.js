// InlineTerms & Definitions for ExpandableInlineText

// Usage in HTML:
// <a href="#" onClick="ShowInline(this,'IEC')" class="Inline">IEC</a>


var L_UNDEFINED_TEXT="Für diesen Text ist keine Zusatzinfo vorhanden.";

function ShowInline(SourceTag, InlineTerm)
{
	var InlineDefinition;
	if (SourceTag.tagName=="A" && SourceTag.getAttribute("State")!="On")
	{

		InlineDefinition = GetInlineDefinition(InlineTerm);

		// Have we found a definition?
		if (InlineDefinition != L_UNDEFINED_TEXT)
		{
			SourceTag.insertAdjacentHTML("BeforeEnd", "<SPAN ID='Pop' class='InlineDef'>&nbsp;&#40;" + InlineDefinition + "&#41;&nbsp;</SPAN>");
			SourceTag.setAttribute("State", "On")
			window.event.returnValue=false;
		}
		else
		{
			alert(L_UNDEFINED_TEXT);
		}
	}
	else if (SourceTag.tagName=="A" && SourceTag.getAttribute("State")=="On")
	{
		SourceTag.all("Pop").outerHTML=""
		SourceTag.setAttribute("State", "Off")
		window.event.returnValue=false;
	}
}


function GetInlineDefinition(InlineTerm)
{
	var def = L_UNDEFINED_TEXT;
	switch (InlineTerm)
	{
	// example definition
		case 'IEC':
			def='IEC: <b>I</b>nternational <b>E</b>lectrotechnical <b>C</b>ommission';
			break;

	// generated definitions

	// end of generated definitions
	}
	return def;
}
