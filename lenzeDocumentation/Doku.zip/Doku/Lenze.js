// functions for expandable information

// definition for .child now in global css
//with (document)
//	{
//	write("<STYLE TYPE='text/css'>");
//	write(".child {display:none}");
//	write("</STYLE>");
//	}

isExpanded = false;
onload = initIt;



function initIt()
	{
	divCollection = document.all.tags("div");
	for (i=0; i<divCollection.length; i++)
		{
		ExpandElement = divCollection(i);
		if (ExpandElement.className == "child")
			ExpandElement.style.display = "none";
		}
	}



function expandAll()
	{
	ExpandImage = (isExpanded) ? "images/folder_plus.gif" : "images/folder_minus.gif";
	ExpandAllImage = (isExpanded) ? "images/checkbox_off.gif" : "images/checkbox_on.gif";

	divCollection = document.all.tags("div");
	for (i=0; i<divCollection.length; i++)
		if (divCollection(i).className == "child")
			divCollection(i).style.display = (isExpanded) ? "none" : "block";

	for (i=0; i<document.images.length; ++i)
		{
		if(document.images[i].name == "expand")
			document.images[i].src= ExpandImage;
		if(document.images[i].name == "expandall")
			document.images[i].src= ExpandAllImage;
		}

	isExpanded = !isExpanded;
	}



function expandIt(LinkElement, ExpandElement)
	{
	ExpandElement = eval(ExpandElement);

	if (LinkElement.tagName=="a" || LinkElement.tagName=="A")
		{
		if (ExpandElement.style.display == "none")
			{
			ExpandElement.style.display = "block";
			if (LinkElement.childNodes[0].name == "expand")
				LinkElement.childNodes[0].src = "images/folder_minus.gif";
			}
		else
			{
			ExpandElement.style.display = "none";
			if (LinkElement.childNodes[0].name == "expand")
				LinkElement.childNodes[0].src = "images/folder_plus.gif";
			for (i=0; i<document.images.length; ++i)
				if(document.images[i].name == "expandall")
					document.images[i].src= "images/checkbox_off.gif";
			isExpanded = false;
			}
		}
	}



// function for linking to an external file
// code from http://www.helpware.net

function ExternLink(datei)
	{
	var path = GetAbsolutePath();
	if (path != '')
		location.href = path + datei;
	}

function GetAbsolutePath()
	{
	var X, Y, sl, a, ra, dir;
	ra = /::/;
	a = location.href.search(ra);
	if (a <= 0) return('');

	//find the index of the first colon in the string
	ra = /:/;
	a = location.href.search(ra);
	if (a == 2)
		X = 14; //prefix = mk:@MSITStore:
		else
		X = 7;  //prefix = ms-its:

	//find last back slash
	sl = "\\";
	Y = location.href.lastIndexOf(sl);
	dir = location.href.substring(X, Y+1);

	//UnEscape path and return path
	return unescape(dir);
	}


function OpenNewWindow(page)
	{
	OpenWin = this.open(page, "HelpWindow", "toolbar=no,menubar=no,location=no,scrollbars=no,resizable=no,width=500,height=300");
	}

function BottomLinkNextPageVisible()
	{
	if (document.getElementById)
		document.getElementById("NextPage").style.visibility = "visible";
	}
